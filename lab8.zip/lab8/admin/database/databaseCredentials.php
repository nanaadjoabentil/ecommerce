 <?php

 define('SERVER', 'localhost');
 define('USERNAME', 'root');
 define('PASSWORD', '');
 define('DBNAME', 'shoppn');
  ?>
